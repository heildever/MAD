package com.example.mad.lab2;

public class invitation_class {

    public String email;
    public Number timestamp;
    public String group;

    public invitation_class(String email, Number timestamp, String group) {
        this.email=email;
        this.timestamp=timestamp;
        this.group=group;
    }

}
