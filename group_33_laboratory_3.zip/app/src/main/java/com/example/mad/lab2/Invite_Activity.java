package com.example.mad.lab2;

import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.firebase.client.Firebase;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import static android.R.id.message;


public class Invite_Activity extends AppCompatActivity {


    private EditText invite_text;
    private String message;
    private String to;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invite);

        invite_text=(EditText) findViewById(R.id.invite_text);

        String GroupID;
        Bundle bundle = getIntent().getExtras();
        GroupID =bundle.getString("GroupID");
        message= GroupID;


        //sendEmail(invite_text.toString(),"invitation to the best group ever",message);

    }
    public void invite_button(View view){
        to= invite_text.getText().toString();
        invitar(to,message);
    }

    public void invitar(final String to, String mes){


        /////////////////////////////////////////////////////////////////////////////////////
        ///////////// INVITE SOMEONE AND ADD the data TO A TEMPORAL DATABASE
 /*       Firebase.setAndroidContext(this);
        Firebase ref = new Firebase(Config.FIREBASE_URL).child("Invitations");

        //Getting values to store
        String mail = to;
        Long tsLong = System.currentTimeMillis()/1000;
        Number timestamp = tsLong;
        String group = mes;
*/

        /*ref.push().setValue(new invitation_class(mail,timestamp,group));*/

        Log.d("to.indexOf('@')<0: ", String.valueOf(to.indexOf('@')));
        if (to.indexOf('@')<0) {
            //USER REGISTERED, UserID hasn't the caracter @

            Firebase modif_usr = new Firebase(Config.FIREBASE_URL).child("Users").child(to).child("groups");
            /*group_name_class group_invitation = new group_name_class("Group1");*/
            /* modif_usr.push().setValue(group_invitation);*/
            modif_usr.push().setValue(message);


        } else {
            //NEW USER send email..... EN ESTE APPROACH SE CREA UN PERFIL DEL USUARIO Q LUEGO SERA MODIFICADO CUANDO EL LLENE LOS CAMPOS
            Log.i("Send email", "");

            String[] TO = {to};
            //String[] CC = {"xyz@gmail.com"};
            Intent emailIntent = new Intent(Intent.ACTION_SEND);
            emailIntent.setData(Uri.parse("mailto:"));
            emailIntent.setType("text/plain");
            String mess="You have an invitation to join the group "+mes+" use this link Https://example.com  and your email in the registration.";

            emailIntent.putExtra(Intent.EXTRA_EMAIL, TO);
            //emailIntent.putExtra(Intent.EXTRA_CC, CC);
            emailIntent.putExtra(Intent.EXTRA_SUBJECT, "subject");
            emailIntent.putExtra(Intent.EXTRA_TEXT,mess);



            try {
                startActivity(Intent.createChooser(emailIntent, "Send mail..."));

                Log.i("Finished sending email", "");

            } catch (android.content.ActivityNotFoundException ex) {
                Toast.makeText(Invite_Activity.this,
                        "There is no email client installed.", Toast.LENGTH_SHORT).show();
            }

            //CREAR USUARIO
            FirebaseAuth mAuth;
                /*mAuth = FirebaseAuth.getInstance();
                Firebase.setAndroidContext(this);*/
            mAuth = FirebaseAuth.getInstance();
            mAuth.createUserWithEmailAndPassword(to, to) //to=correo y to=contraseña (son el correo las dos)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {

                            Log.d("createUserWithEmail:onComplete:", String.valueOf(task.isSuccessful()));
                            //hideProgressDialog();

                            // If sign in fails, display a message to the user. If sign in succeeds
                            // the auth state listener will be notified and logic to handle the
                            // signed in user can be handled in the listener.
                            Log.d("[*] [*] [*] task.getResult().getUser().getUid(): ",task.getResult().getUser().getUid().toString());
                          /*      Log.d("[*] [*] [*] task.getResult().getUser().getUid(): ",task.getResult().toString());
                                Log.d("[*] [*] [*] task.getResult().getUser().getUid(): ",task.getResult().getUser().toString());
                                Log.d("[*] [*] [*] task.getResult().getUser().getUid(): ",task.getResult().getUser().getUid().toString());
*/
                            if (!task.isSuccessful()) {
                                Toast.makeText(Invite_Activity.this, "Authentication failed.",
                                        Toast.LENGTH_SHORT).show();

                            } else {

                                //Log.d(TAG, "getresult:" + task.getResult().toString());
                                //Log.d(TAG, "getresult:" + task.getResult().getUser().toString());
                                //Log.d(TAG, "getresult:" + task.getResult().getUser().getUid().toString());

                            /*onAuthenticationSucess(task.getResult().getUser());*/
                                    /*onAuthenticationSucess(task.getResult().getUser());*/
                                User user= new User(task.getResult().getUser().getUid(), "temp_name", "temp_num", to, to);
                                Firebase mRef = new Firebase("http://lab2-a0a02.firebaseio.com/");
                                mRef.child("Users").child(task.getResult().getUser().getUid()).setValue(user);

                                //agregar el grupo. la funcion setGroup no sirve porque no pone el ID, se hace con el push() de firebase
                                Firebase modif_usr = new Firebase(Config.FIREBASE_URL).child("Users").child(task.getResult().getUser().getUid()).child("groups");
                                modif_usr.push().setValue(message);
                                FirebaseAuth.getInstance().signOut();
                                FirebaseAuth.AuthStateListener mAuthListener;
                                mAuthListener = new FirebaseAuth.AuthStateListener() {
                                    @Override
                                    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                                        Task<AuthResult> user = firebaseAuth.signInWithEmailAndPassword("daniel@daniel.com","danieldaniel");
                                        finish();
                                    }
                                };

                            }



                            /// RECONECTAR EL USUARIO, pq cuando se creo el nuevo se quedó logueado con ese nuevo

                            //finish();
                            /// FIN RECONECTAR USUARIO
                        }
                    });




        }




        /////////////////////////////////////////////////////////////////////////////////////////
        finish();

    }

}


class group_name_class{

    public String group;
    public group_name_class(String group) {
        this.group=group;
    }

}
