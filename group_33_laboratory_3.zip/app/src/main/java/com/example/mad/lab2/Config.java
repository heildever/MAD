/**
 * Created by daniel on 05/04/17.
 */


package com.example.mad.lab2;

/**
 * Created by Belal on 2/23/2016.
 */
public class Config {
    public static final String FIREBASE_URL = "http://lab2-a0a02.firebaseio.com/";

}